package servicios;

import modelo.Usuario;
import modelo.dao.GestorUsuarios;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Cliente;
import modelo.dao.GestorCliente;

@WebServlet
public class ServicioRegistro extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        response.setHeader("cache-control", "no-cache, no-store, must-revalidate");
        GestorUsuarios gUsuarios= GestorUsuarios.obtenerInstancia();
        GestorCliente gCliente = GestorCliente.obtenerInstancia();
        String usuario=request.getParameter("usua");
        String password = request.getParameter("pass");
        String rol = request.getParameter("rol");
        String nombre = request.getParameter("nom");
        String apellidos = request.getParameter("ape");
        String telefono = request.getParameter("tel");
        int ro=Integer.parseInt(rol);
        boolean registrarUsuario=false;
        boolean registrarCliente = false;
        
        if(usuario != null && password != null && rol!=null){
            Usuario u=new Usuario(usuario,password,"1",ro);
            registrarUsuario=gUsuarios.registrarUsuario(u);
            if(rol.equals("0")){
            Cliente c = new Cliente(usuario,usuario,apellidos,nombre,telefono);
            registrarCliente=gCliente.registrarCliente(c);
            }
            response.sendRedirect("login.jsp");
        }
        else{
        RequestDispatcher rd = request.getRequestDispatcher("errorRegistro.jsp");
        rd.forward(request, response);
        }

   
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods.">
   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // No permite que los datos del usuario sean recibidos por
        // medio de GET.
        response.sendRedirect("errorIngreso.jsp?error=0");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servicio de ingreso de cuentas";
    }// </editor-fold>
}
